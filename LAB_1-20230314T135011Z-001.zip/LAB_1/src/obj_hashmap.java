import java.util.*;

public class obj_hashmap {
	String usn,name;
	
	obj_hashmap(String usn, String name)
	{
		this.usn = usn;
		this.name = name;
	}
	
	void add(Map<String,String> hmap)
	{
		hmap.put(this.usn, this.name);
	}
	
	void display(Map<String,String> hmap)
	{
		System.out.println(hmap);
	}
	
	void update(Map<String,String> hmap)
	{
		hmap.replace(this.usn, this.name);
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		obj_hashmap obj = null;
		
		String usn,name;
		Map<String,String> hmap = new HashMap<>();
		
		System.out.println("----MENU----");
		System.out.println("1. Add");
		System.out.println("2. Display");
		System.out.println("3. Update");
		
		while(true)
		{
			System.out.print("Enter your choice : ");
			int ch = sc.nextInt();
			if(ch==1)
			{
				System.out.print("Enter USN : ");
				usn = sc.next();
				System.out.print("Enter Name : ");
				name = sc.next();
				obj = new obj_hashmap(usn,name);
				
				obj.add(hmap);
			}
			else if(ch==2)
				obj.display(hmap);
			else if(ch==3)
			{
				System.out.print("Enter USN to update the name: ");
				usn = sc.next();
				System.out.print("Enter new Name : ");
				name = sc.next();
				
				obj = new obj_hashmap(usn,name);
				
				obj.update(hmap);
			}
		}	
	}

}
