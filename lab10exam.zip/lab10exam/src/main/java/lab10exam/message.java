package lab10exam;

public class message {
int id ;
String message;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
@Override
public String toString() {
	return "message [id=" + id + ", message=" + message + "]";
}

}
