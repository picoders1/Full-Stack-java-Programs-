package lab10exam;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Rcontroller {
 ArrayList<message> m1 = new ArrayList<message>();
	
	@RequestMapping("/")
	public String index()
	{
		return "Welcome to index";
		
	}
	
	@PostMapping("/add")
	public String add(@RequestParam int id ,@RequestParam String Message)
	{
		message m = new message();
		m.setId(id);
		m.setMessage(Message);
		m1.add(m);
		return m.toString();
	}
	
	@GetMapping("/display/{id}")
	public String display(@PathVariable int id)
	{
		for (message m:m1)
		{
			if (m.getId()== id)
			{
				return m.toString();
			}
			
		}
		return "not founded";
		
	}

		
	
	
	
	@PutMapping("/update")
	public String update(@RequestParam int id , @RequestParam String message)
	{
		for (message m:m1)
		{
			if (m.getId()== id)
			{	m.setMessage(message);
				return m.toString();
			}
			
		}
		return "not founded ";
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id )
	{

		for (message m:m1)
		{
			if (m.getId()== id)
			{	m1.remove(m);
				return m.toString();
			}
			
		}
		return "not found";
	}
	
	@GetMapping("/display/")
	public String display1()
	{
		String z="";
		for (message m:m1)
		{z+=m.toString();
			
		}
		return z;
		
	}

	
	
}
